import './css/Loader.css';
export default function Loader() {
  return (
    <div className="loader">Loading...</div>
  )
}
